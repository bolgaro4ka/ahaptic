# capacitor-advanced-haptics

Advanced haptic engine for Android

## Install

```bash
npm install capacitor-advanced-haptics
npx cap sync
```

## API

<docgen-index>

* [`vibrate(...)`](#vibrate)
* [`cancel()`](#cancel)

</docgen-index>

<docgen-api>
<!--Update the source file JSDoc comments and rerun docgen to update the docs below-->

### vibrate(...)

```typescript
vibrate(options?: { duration?: number | undefined; amplitude?: number | undefined; } | undefined) => Promise<void>
```

| Param         | Type                                                    |
| ------------- | ------------------------------------------------------- |
| **`options`** | <code>{ duration?: number; amplitude?: number; }</code> |

--------------------


### cancel()

```typescript
cancel() => Promise<void>
```

--------------------

</docgen-api>
